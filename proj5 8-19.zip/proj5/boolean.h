enum _myBool { FALSE = 0, TRUE = 1 };
typedef enum _myBool newBool;