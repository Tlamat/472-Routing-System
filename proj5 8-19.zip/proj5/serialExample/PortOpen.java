/*
 * Port Open (class)
 * 
 * Michael Beauchamp
 * University of Washington (Teaching Assistant)
 * EE 472 - Summer 2006
 * 
 * Modified by Walker Robb
 * University of Washington (Teaching Assitant)
 * EE 472 - Spring 2007
 *
 * Connects to a serial port specified by user.
 * 
 * In order for this class to work the user must get and properly install the 
 * correct Java Communications API for their platform.  This can downloaded 
 * from the Sun Developer Network (SDN) at 
 * http://java.sun.com/products/javacomm/
 * THIS HAS ALREADY BEEN COMPLETED FOR THE LAB COMPUTERS.
 * 
 * The Java Communications API for windows consists of three files comm.jar, 
 * win32com.dll, and javax.comm.properties.  These files must be placed in the 
 * correct locations.  See Rick Proctor's Java Communications API: A Working 
 * Example at http://bdn.borland.com/article/31915 for specifics.
 * THIS HAS ALREADY BEEN COMPLETED FOR THE LAB COMPUTERS.
 * 
 * This code (class) is based largely on the book Java Cookbook by Ian Darwin, 
 * specifically chapter 11: Programming Serial and Parallel Ports
 * http://java.sun.com/developer/Books/javaprogramming/cookbook/11.pdf
 * 
 * And, "The Java Communications API: A Working Example" by Rick Proctor.
 * http://bdn.borland.com/article/31915
 * 
 * For assistance see the Java 2 Platform, Standard Edition 5.0, API 
 * Specification at http://java.sun.com/j2se/1.5.0/docs/api/
 * 
 */

import java.io.*;
import javax.comm.*;
import java.util.*;

public class PortOpen implements SerialPortEventListener {

	/** How long to wait for the open to finish up. */
	public static final int TIMEOUTSECONDS = 30;

	/** The baud rate to use. */
	public static final int BAUD = 19200;
	
	/** The input stream */
	protected DataInputStream is;
	
	/** The output stream */
	protected PrintStream os;
	
	/** The complete input from the serial port */
	public String scannedInput;
	
	/** GUI to interact with **/
	protected SimpleGUI gui;
	
	/** data to be sent **/
	public String readyOutput;
	
	/** data ready to send flag **/
	boolean sendFlag = false;

	/** The chosen Port Identifier */
	CommPortIdentifier thePortID = null;
	
	/** The chosen Port itself */
	CommPort thePort;
	
	/** data ready to process flag */
	boolean dataReady = false;


	/** 
	 *	PORT OPEN (Constructor)
	 * 
	 *	The constructor is complete and you should not have to modify it, but you 
	 *	should take a look at it and see how it works.  The input is a string 
	 *	consisting of either "COM1" or "COM2".  The constructor sets up the serial 
	 *	communicaion port including the baud rate, number of data bits, the stop 
	 *	bits, parity, and flow control.  It also sets up the input stream, output 
	 *	stream, and the event listener.
	 * 
	 */
	public PortOpen(String desiredPort)
		throws IOException, NoSuchPortException, PortInUseException,
			UnsupportedCommOperationException {

		System.out.println("Serial Port by Michael Beauchamp's.");
		System.out.println("based on Ian Darwin's book Java Cookbook\n");
		
		System.out.println("Creating list of available ports ... ");
		System.out.println("Looking for port " + desiredPort + " ... ");
		
		// Get list of ports on this particular computer by calling static
		// method in CommPortIdentifier.  The ports, type (serial or parallel), and 
		// ownership are listed.  If found, the desired port is noted.
		Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();
		
		while (portEnum.hasMoreElements()) {
		
			CommPortIdentifier cpi = (CommPortIdentifier) portEnum.nextElement();
			
			System.out.print("\tPort " + cpi.getName());
			
			if ( cpi.getPortType() == CommPortIdentifier.PORT_SERIAL)
				System.out.print(" - Serial Port   ");
			else if ( cpi.getPortType() == CommPortIdentifier.PORT_PARALLEL)
				System.out.print(" - Parallel Port ");
			else
				System.out.print(" - UNKNOWN Port  ");
			
			if ( cpi.isCurrentlyOwned() )
				System.out.println("Owned");
			else
				System.out.println("Unowned");
				
			if ( desiredPort.compareTo(cpi.getName()) == 0 )
				thePortID = cpi;
			
		}
		
		// Check to ensure the desired port was found.
		if ( thePortID != null )
			System.out.println("Found port " + thePortID.getName() + " ... ");
		else 
			throw new IllegalStateException("ERROR: No such port found.");
		
		// Check to ensure the desired port is a serial port.
		if ( thePortID.getPortType() != CommPortIdentifier.PORT_SERIAL )
			throw new IllegalStateException("ERROR: Selected port is not a SERIAL port.");
		
		// Check to ensure the desired port is not in use.
		if ( thePortID.isCurrentlyOwned() )
			throw new IllegalStateException("ERROR: Selected port is in use.");
		
		// Open the port.  This form of openPort takes an Application Name and a 
		// timeout.
		System.out.print("Trying to open port " + thePortID.getName() + " ... ");		 
		thePort = thePortID.open("EE472 DataComm", TIMEOUTSECONDS * 1000);
		SerialPort myPort = (SerialPort) thePort;
		System.out.println("Done");
		

		// set up the serial port
		// BaudRate
		// DataBits
		// 		DATABITS_5		5 data bit format. 
		// 		DATABITS_6		6 data bit format.
		//		DATABITS_7		7 data bit format.
		//		DATABITS_8		8 data bit format.
		//	StopBits
		//		STOPBITS_1				Number of STOP bits - 1.
		//		STOPBITS_1_5			Number of STOP bits - 1-1/2.
		//		STOPBITS_2				Number of STOP bits - 2.
		//	Parity
		//		PARITY_EVEN				EVEN parity scheme.
		//		PARITY_MARK				MARK parity scheme.
		//		PARITY_NONE				No parity bit.
		//		PARITY_ODD				ODD parity scheme.
		//		PARITY_SPACE			SPACE parity scheme.
		System.out.print("Setting " + thePortID.getName() + "s parameters ... ");
		try {
			myPort.setSerialPortParams(BAUD, 
										SerialPort.DATABITS_8, 
										SerialPort.STOPBITS_1, 
										SerialPort.PARITY_NONE);	
		} catch (UnsupportedCommOperationException e) {
			System.out.println("FAILED");
			throw new UnsupportedCommOperationException("ERROR: Incorrectly specified parameters.");
		}

		// Set up the flow control.
		//		FLOWCONTROL_NONE		Flow control off.
		//		FLOWCONTROL_RTSCTS_IN	RTS/CTS flow control on input.
		//		FLOWCONTROL_RTSCTS_OUT	RTS/CTS flow control on output.
		//		FLOWCONTROL_XONXOFF_IN	XON/XOFF flow control on input.
		//		FLOWCONTROL_XONXOFF_OUT	XON/XOFF flow control on output.
		
		try {
			myPort.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);	
		} catch (UnsupportedCommOperationException e) {
			System.out.println("FAILED");
			throw new UnsupportedCommOperationException("ERROR: Incorrectly specified flowcontrol.");
		}

		System.out.println("Done");		
			
		// Attempt to get the input stream.
		System.out.print("Getting input stream ... ");
		try {
			is = new DataInputStream(thePort.getInputStream());
		} catch (IOException e) {
			is = null;
			System.out.println("FAILED");
			throw new IOException("ERROR: Can not open input stream.");
		}
		System.out.println("Done");
		
		// Create the output stream.
		System.out.print("Creating output stream ... ");
		os = new PrintStream(thePort.getOutputStream(), true);
		System.out.println("Done");
		
		// Add the event listener.
		System.out.print("Adding event listener ... ");
		try {
			myPort.addEventListener(this);
		} catch (TooManyListenersException e) {
			System.out.println("FAILED");
			throw new IllegalStateException("ERROR: Too many listeners.");
		}
		myPort.notifyOnDataAvailable(true);
		System.out.println("Done");
		
		// Now ready to read and write to the serial port.
		System.out.println("\nReady to read and write port.\n");
		
	}
	
	/**
	 * 
	 *	CONVERSE
	 * 
	 *	The is the main block of the code that will control the serial 
	 *	communication.  The data ready flag is set in the serial event, which 
	 *	takes information from the input stream and places it in the 
	 *  scannedInput.  Based on the input you can write to the output stream 
	 *	using "os.write".
	 * 
	 */
	protected void converse() throws IOException {
		
		boolean quit = false;	
		
		while (!quit) {
			
			// The data ready flag is set by the serial event when there is data in the 
			// read buffer.
			if (dataReady) {



				// Place your main code here.  Here is where you will parse the
				// input (scannedInput) and send the output.  The serial event 
				// will take the input from the input stream and put it in the 
				// scannedInput.  After parsing the read buffer, set the data 
				// ready flag to false.  Write to the output stream using 
				// "os.write".  There should not be any reason to exit the 
				// while loop, but if you do desire to exit the while loop, 
				// have a condition that will set quit to true.
				
				// we can't send data to the gui if we don't have a handle on a gui object yet
				// see associateGUI(SimpleGUI object)
				if(gui != null)
					gui.enterData(scannedInput);

				dataReady = false;

			}
			
			if (sendFlag) {
				
				// Some other important code will be placed here. The send flag
				// could be modified by the user through the GUI as shown now 
				// (check out SimpleGUI.java), or by some other method you chose.
				
				os.print(readyOutput);

				sendFlag = false;
			}
			
			
		}
			
		// Clean up streams
		is.close();
		os.close();
		
		System.out.println("\nInput and output streams closed.");
	}
	
	// method to allow other classes to access the sendFlag
	public void setSendFlag(boolean value) {
		sendFlag = value;
	}
	
	// method allowing other classes to access the data to send
	protected void setSendData(String value) {
		readyOutput = value;
	}
	
	// the main java file uses this method to send us a GUI object to interact with..
	protected void associateGUI(SimpleGUI object) {
		gui = object;
	}

	/**
	 *	SERIAL EVENT
	 * 
	 *	Serial event is an event listener that will take data, as available, 
	 *	from the input stream and place it in a string called scannedInput.  
	 *	ScannedInput is what you want to parse in Converse.  When the end of 
	 *	the data has been received (a newline character -> 0x0A) the dataReady 
	 *  flag will be set.  Depending on how you set up your code you might 
	 *  want to modify this code.
	 * 
	 */
	public void serialEvent(SerialPortEvent event) {

		int FRAME_END = 0x0A;
		
		switch(event.getEventType()) {
			case SerialPortEvent.BI:
			case SerialPortEvent.OE:
			case SerialPortEvent.FE:
			case SerialPortEvent.PE:
			case SerialPortEvent.CD:
			case SerialPortEvent.CTS:
			case SerialPortEvent.DSR:
			case SerialPortEvent.RI:
			case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
				break;
			case SerialPortEvent.DATA_AVAILABLE:
				StringBuffer readBuffer = new StringBuffer();
				int c;
				try {

					// Read the transmission into a string buffer until the end
					// of the transmission is found.
					while ( ( c = is.read() ) != ( (char) FRAME_END ) ) {
						readBuffer.append((char) c);
					}
					
					// Read the last char of the transmission into a string 
					// buffer.
					readBuffer.append((char) c);

					// Once the end of the transmission has been found, convert
					// the string buffer into a string and set the data ready 
					// flag.
					scannedInput = readBuffer.toString();
					dataReady = true;
					 
				} catch (IOException e) {}
				break;
		}

	}
	
}
