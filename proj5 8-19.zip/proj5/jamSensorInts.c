#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <string.h>
#include "boolean.h"
#include "td40.h"
#include "TCB_Data_Structs.h"

#define BUFFSIZE		2000		

extern newBool jamPresent;
extern char line[50];

void interrupt far jamAq_ISR()
{
//   int s0 = pio_rd(29);
//   int s1 = pio_rd(9);

	unsigned int s0 = pio_rd(29);
	unsigned int s1 = pio_rd(9);
	
	jamPresent = TRUE;

   if(s0  == 1 && s1 == 1) {
    	sprintf(line,"Right");
	} else if(s0 && !s1) {
    	sprintf(line,"Left");
	} else if(s1 && !s0) {
    	sprintf(line,"Forward");
	} else {
		sprintf(line,"False Alarm");
	}
   // EOI
   outport(0xFF22,0x8000);
}

