#include "boolean.h"
#include "ucos.h"
#include "td40.h"
#include "TCB_Data_Structs.h"
#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <string.h>

#define OFF 	0x13
#define ON     0x11

#define TASK7_PRIORITY		23
#define STACK_SIZE			1024

void far ParseTask(void* data);

void far SerialTask(void* data)
{

	char RXBuffer[75];
	char TXBuffer[75];
	char lenStr[5];
   char ackBuffer[5];
   newBool ack;
	int TXPos = 0;
	int RXPos = 0;
   int TXSend = 0;
   int length = 0;
   int ackTry;
   int i = 0;
   int z = 0;
   int wrEN  = 0;     // write enable
   newBool rxFull = FALSE;

   while(1) {

		// Get data for serial communications
		TaskDataSerCom* SerData = (TaskDataSerCom*)data;

      wrEN = 0;
      length = 0;
      RXPos = 0;
      TXPos = 0;
      TXSend = 0;
      ackTry = 0;
      ack = 'n';
      // If we are Recieving
		while(serhit1(*(SerData->cPtr)) && RXPos < 75){
        	*(SerData->recievePtr) = TRUE;
			RXBuffer[RXPos] = getser1(*(SerData->cPtr));

         if(RXPos == 70) {
				// Send OFF to parse task
           	// putser1(OFF,*(SerData->cPtr));
				rxFull = TRUE;
         }

         if(RXPos <= 50 && rxFull) {
         	// Send ON to parse Task
            rxFull = FALSE;
         }

      	RXPos = RXPos + 1;

			// If you get a carriage return
         if(RXBuffer[RXPos-1] == '\n') {
	         // get length
            sprintf(lenStr,"%c%c%c%c",RXBuffer[1], RXBuffer[2], RXBuffer[3], RXBuffer[4]);
            // length ATOI not working if Hex digit..works fine for Decimel
            length = atoi(lenStr);
				// Extract Payload
            for(i = 0; i < length-6;i++) {
					// Put payload into a buffer
					(SerData->aRXBufferPtr)[*(SerData->aRXBposPtr)] = RXBuffer[i+5];
              	RXBuffer[i+5] = NULL;
               *(SerData->aRXBposPtr) = *(SerData->aRXBposPtr) + 1;
      		}
				RXPos = 0;
         }
      }

      if(*(SerData->recievePtr)) {
      	OSTaskCreate(ParseTask, (void*)&*(SerData->ParseTaskDataPtr), (void*)&(SerData->Task7StkPtr)[STACK_SIZE-1], TASK7_PRIORITY);
      }


   	// Transmitting
      while(*(SerData->transmitParsedPtr)) {
			// get chars from aTXbufferptr and put chars into transmit buffer
			while((SerData->aTXBufferPtr)[TXPos] != NULL) {
				TXBuffer[TXPos] = *(SerData->aTXBufferPtr+TXPos);
				*(SerData->aTXBufferPtr+TXPos) = NULL;
				TXPos = TXPos + 1;
           	*(SerData->aTXBposPtr) = *(SerData->aTXBposPtr) - 1;
        	}

			// transmit to serial port
///         if(75 == TXPos || (SerData->aTXBufferPtr+TXPos) == NULL) {
//				while(!ack && ackTry < 4) {
					TXSend = TXPos;
               TXPos = 0;
	      	  	while (TXSend >= 0) {
						wrEN = inport(0xFF12);        // "...get serial port status..."
						if( (wrEN>>6) & 1) { 			// "if permission bit is 1..."
							outport(0xFF14, TXBuffer[TXPos]);   //"write the next char..."
							TXBuffer[TXPos] = NULL;
                     TXPos++;
  			   			TXSend = TXSend - 1;              //"increment to the next char"
  						}
//					}
          /*  	// End Writing, Ack Check
	            while(!serhit1(*(SerData->cPtr)));		// wait for response
   	       	while(serhit1(*(SerData->cPtr))){
      	    		ackBuffer[z] = getser1(*(SerData->cPtr));
         	 		z++;
            	}
	            z = 0;
   	         if((int)ackBuffer[1] == 0x06) {
      	        	ack = TRUE;
         	   }
            	ackTry = ackTry + 1;
					if(ackTry > 3) {
   	           	// Transmit Error - Re-initialize
      	         lcd_movecursor(0x80);
						lcd_fillrow(1, ' ');
            	   lcd_movecursor(0x80);
               	lcd_putstr("Re-initialize Serial Port");
	          	}*/
//         	}
   	   }

			if((SerData->aTXBufferPtr)[TXPos] == NULL) {
 				*(SerData->transmitParsedPtr) = FALSE;
	  	      *(SerData->aTXBposPtr) = 0;
            ackTry = 0;
            ack = FALSE;

		 	}

      	*(SerData->idErrorPtr) = FALSE;
	  	   *(SerData->sizeErrorPtr) = FALSE;
   	}
		OSTimeDly(5);
	}
//   return;
}
