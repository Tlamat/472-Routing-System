/************************
 * Author Walker Robb
 * University of Washington
 * EE 472 TA - Spring 2007
 * 
 * SimpleGUI (class)
 * 
 ************************/

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

class SimpleGUI extends JFrame  implements ActionListener
{
    protected JTextField textField0 = new JTextField(40);
    protected JTextArea textArea0 = new JTextArea(12,40);
    protected JScrollPane scrollPane0 = new JScrollPane(textArea0);
    protected Container aContainer;
    protected JPanel aPanel0 = new JPanel();
    protected JLabel aLabel0 = new JLabel("INPUT:");
    protected JLabel aLabel1 = new JLabel("OUTPUT:");
    protected PortOpen aPort;
    
    public int seqNum = 0 ;
    public boolean ack = false;
    public boolean nak = false;
    public int ackTry = 0;
    public String textString = "";
    public boolean initialize = false;
    
    public SimpleGUI(PortOpen port)
    {
    	// name the panel
    	super("Simple Interface");
    	
    	// we want the program to terminate if someone closes the window
    	addWindowListener(new WindowAdapter()
        {
           public void windowClosing(WindowEvent e)
           {
             dispose();
             System.exit(0); //calling the method is a must
           }
        });
    	
        //  set the initial value in the text field
        textField0.setText("Type Here!");
        
        // actively observe the text field for entries
        textField0.addActionListener(this);
        
        // configure the frame and add a panel
        aContainer = this.getContentPane();
        aContainer.setLayout(new GridLayout(1,1) );
        aContainer.add(aPanel0);
        
        // put the containers together
        aPanel0.add(aLabel0);
        aPanel0.add(textField0);
        aPanel0.add(aLabel1);
        aPanel0.add(scrollPane0);
        scrollPane0.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane0.setViewportBorder(BorderFactory.createLoweredBevelBorder());
        
        // make sure the user can see it!
        this.setVisible(true);
        
        // save a reference to the port we are using
        aPort = port;
    }
    
    public void actionPerformed (ActionEvent anEvent)
    {
    	ack = false;
    	nak = false;
    	// as a demo, you see here you can get some information on the
    	String paramString = anEvent.paramString();
    	
        // if event occurs in the text field, save it in out output buffer
    	String aString = textField0.getText();
    	textString = aString;
    	
    	transmitText(textString);
    	
//     	output some info. about the event to the debug console
    	System.out.println(paramString);  
    	
    	// clear the input text field after the event
    	textField0.setText(null);
    	
    	// move the scroll bar automatically (if necessary)
    	textArea0.setCaretPosition(textArea0.getDocument().getLength());

    }
    
    // allows an external class to send text to the text area
    public void enterData(String data)
    {
    	
    	String IFdata = "";
    	int length = 0;
    	int checksum = 0;
    	
    	textArea0.append("Rcvd:");
		textArea0.append(data);
//		textArea0.append("\n");
		
    	
   /* 	if(data.charAt(1) == 0x06) {
    		ack = true;
    		nak = false;
    		ackTry = 0;
//    		textArea0.append("Got Ack\n");
    	} else if(data.charAt(1) == 0x15){
    		ack = false;
    		nak = true;
//    		textArea0.append("Got Nak\n");
    		if(ackTry < 4) {
    			transmitText(textString);
    		} else {
    			textArea0.append("Serial Link Down, Please Re-initialize");
    		}
    		ackTry++;
    	} else {*/	
//    		textArea0.append("Got Info Frame\n");
    		// Information Frame, Get Payload
    		length = Integer.parseInt(data.substring(1,5), 16);
    		/*textArea0.append("length");
    		textArea0.append(data.substring(1,5));
    		textArea0.append("\n");
    		textArea0.append("length");
    		textArea0.append(String.valueOf(length));
    		textArea0.append("\n");*/
    		IFdata = data.substring(5, length-1);
    		/*textArea0.append("Substring:");
    		textArea0.append(IFdata);
    		textArea0.append("\n");*/

    		// Check Checksum  		
    		for(int i = 0;i<length-1;i++) {
    			checksum = (char)checksum ^ (char)data.charAt(i);
    		}
    		
    		/*textArea0.append("CheckSum of Java: ");
    		textArea0.append(Integer.toHexString(checksum));
    		textArea0.append("\n");
    		textArea0.append("CheckSum of Paradigm: ");
    		textArea0.append(data.substring(length-1, length+2));
    		textArea0.append("\n");
    		textArea0.append("CompareTo: ");
    		textArea0.append(Integer.toHexString((data.substring(length-1, length+2)).compareTo(Integer.toHexString(checksum))));
    		textArea0.append("\n");*/
    		/*if((data.substring(length-1, length+2)).compareTo(Integer.toString(checksum)) >= 0) {
    			// Send an AckFrame
    			seqNum = (seqNum + 1)%8;
    			char[] ackFrame = new char[4];
    			ackFrame[0]= 0x01;
    			ackFrame[1] = 0x06;
    			ackFrame[2] = '1';
    			ackFrame[3] = 0x0A;
    			aPort.setSendData(String.copyValueOf(ackFrame));
    			aPort.setSendFlag(true);
    			ack = true;
    			nak = false;
    		} else {
    			ack = false;
    			nak = true;
    			seqNum = (seqNum + 1)%8;
    			char[] nakFrame = new char[4];
    			nakFrame[0]= 0x01;
    			nakFrame[1] = 0x15;
    			nakFrame[2] = '1';
    			nakFrame[3] = 0x0A;
    			aPort.setSendData(String.copyValueOf(nakFrame));
    			aPort.setSendFlag(true);
    		}
    	
    		if(ack) {*/
    			// Payloads
    			// M Frame
    			if(IFdata.charAt(0) == 'M') {
    				textArea0.append("Idenfitication: ");
    				textArea0.append(IFdata.substring(6, 14));
    				textArea0.append("\n");
    		
    				textArea0.append("Size: ");
    				textArea0.append(IFdata.substring(14, 16));
    				textArea0.append("\n");
    		
    				textArea0.append("Direction: ");
    				if(IFdata.substring(16, 18).compareTo("LF") == 0){
    					textArea0.append("Left");
    				} else if(IFdata.substring(16, 18).compareTo("FW") == 0){
    					textArea0.append("Forward");
    				} else if(IFdata.substring(16, 18).compareTo("RT") == 0){
    					textArea0.append("Right");
    				}
    				textArea0.append("\n");
    				// 	A Frame
    			} else if(IFdata.charAt(0) == 'A') {
    				if(IFdata.substring(2, 4).compareTo("JP") == 0) {
    					textArea0.append("Jam Present: ");
    					textArea0.append(IFdata.substring(4,7));
    					textArea0.append("\n");
    					textArea0.append("Direction: ");
    					if(IFdata.substring(7,9).compareTo("LF") == 0){
        					textArea0.append("Left");
        				} else if(IFdata.substring(7,9).compareTo("FW") == 0){
        					textArea0.append("Forward");
        				} else if(IFdata.substring(7,9).compareTo("RT") == 0){
        					textArea0.append("Right");
        				}
    					textArea0.append("\n");
    				}
    				if(IFdata.substring(9,11).compareTo("BI") == 0) {
    					textArea0.append("Bad Identification: ");
    					textArea0.append(IFdata.substring(11,18));
    					textArea0.append("\n"); 			
    				} 
    			} else if(IFdata.charAt(0) == 'E') {
    				textArea0.append("Incorrect or Non-Existant Command\n");
    			} 
    			ack = false;
    			nak = false;
    		//}
    	//}
    	// 	move the scroll bar automatically (if necessary)
    	textArea0.setCaretPosition(textArea0.getDocument().getLength());
    }


    private void transmitText(String aString) 
	{	
		char[] IFrameC = new char[8+aString.length()];
		int checksum = 0;
		String checksumStr = "";

		// Build Information Frame	
		checksum = 0;
		checksumStr = "";
		// Start
		IFrameC[0] = 0x01;
	
		checksum = (char)checksum ^ (char)0x01;
		
		// length
		int length = 6 + aString.length();
		String lengthStr = Integer.toHexString(length);
		while(lengthStr.length() < 4) {
			lengthStr = "0" + lengthStr;		
		}
		for(int i = 0;i<4;i++) {
			//IFrame[i+1] = lengthStr.charAt(i);
			IFrameC[i+1] = lengthStr.charAt(i);
			checksum = (char)checksum ^ (char)IFrameC[i+1];
		}
		// Text
		for(int i = 0;i < aString.length();i++){
			checksum = (char)checksum ^ aString.charAt(i);
			//IFrame[i+5] = aString.charAt(i);
			IFrameC[i+5] = aString.charAt(i);
		}

		// Check
		checksumStr = Integer.toHexString(checksum);
		if(checksumStr.length() < 2 ) {
			checksumStr = "0" + checksumStr;
		}
		
		for (int i = 0; i < 2; i++) {
			//IFrame[i+5+aString.length()] = checksumStr.charAt(i);
			IFrameC[i+5+aString.length()] = checksumStr.charAt(i);
		}    		
		// 	End 
		IFrameC[7+aString.length()] = 0x0A;  
	    		
	
	// print to the console window and the output text area
	textArea0.append("Sent:");
	textArea0.append(String.copyValueOf(IFrameC));
	
	// send this string over the serial port, so we save it and set a flag
	aPort.setSendData((String.copyValueOf(IFrameC)));
	aPort.setSendFlag(true);

	}
}