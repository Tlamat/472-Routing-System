/*
 * MAIN TEST (class)
 * 
 * Michael Beauchamp
 * University of Washington (Teaching Assistant)
 * EE 472 - Summer 2006
 * 
 * Modified by Walker Robb
 * University of Washington (Teaching Assitant)
 * EE 472 - Spring 2007
 *
 * Wrapper class for Port Open.
 * 
 * You should not have to modify this code.
 * 
 */

import java.io.*;
import javax.comm.*;



public class MainTest {
		
	public static void main(String[] args) {
		
		PortOpen myPort = null;
		
		try {
			myPort = new PortOpen("COM2"); // specify here the port you wish to connect to...
		} catch (IOException e) {

		} catch (NoSuchPortException e) {
			
		} catch (PortInUseException e) {
			
		} catch (UnsupportedCommOperationException e) {
			
		}
		
        SimpleGUI myGUI = new SimpleGUI(myPort);
        myGUI.setSize(500,300);
        myGUI.setVisible(true);
        myPort.associateGUI(myGUI);
		 
		try {
			myPort.converse();
		} catch (IOException e) {
			
		}

	}

}
